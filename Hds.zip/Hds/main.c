#include "stm32f10x.h"
#include "ST7789.h"
#include "delay.h"
#include "xpt2046.h"
#include "GUI.h"
#include "DS18B20.h"
#include "MQ135.h"
#include "put_sign.h"
#include "HC08.h"
//extern float _temp;
extern volatile GUI_TIMER_TIME OS_TimeMS;
uint16_t T_times=0;
uint16_t T6_times=0;
extern struct Temp_s temp_s;
void tim6_init()
{
	//1ms
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6,ENABLE); //��ʱ��7ʱ��ʹ��
	TIM_TimeBaseInitTypeDef t;
	t.TIM_ClockDivision=TIM_CKD_DIV1;
	t.TIM_Period=999;
	t.TIM_Prescaler=71;
	t.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM6,&t);
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE);//���������ж�
	NVIC_InitTypeDef n;
	n.NVIC_IRQChannel= TIM6_IRQn;
	n.NVIC_IRQChannelCmd=ENABLE;
	n.NVIC_IRQChannelPreemptionPriority=1;
	n.NVIC_IRQChannelSubPriority=1;
	NVIC_Init(&n);
	TIM_Cmd(TIM6,ENABLE);
}

///
//tim6�������ݲɼ�
///
void TIM6_IRQHandler()
{
	if(TIM_GetITStatus(TIM6,TIM_IT_Update)!=RESET)
	{	
		T6_times++;
		if(T6_times>800)//800msһ��
		{
			
			temp_s.temp=DS18B20_Get_Temp();
			temp_s.strart=1;//��һ��ת������
			T6_times=0;//����
			temp_s.end=1;//ת�����
		}
	}
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);
}
void _tim_init()
{
	//1ms
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7,ENABLE); //��ʱ��7ʱ��ʹ��
	TIM_TimeBaseInitTypeDef t;
	t.TIM_ClockDivision=TIM_CKD_DIV1;
	t.TIM_Period=999;
	t.TIM_Prescaler=71;
	t.TIM_CounterMode=TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM7,&t);
	TIM_ITConfig(TIM7,TIM_IT_Update,ENABLE);//���������ж�
	NVIC_InitTypeDef n;
	n.NVIC_IRQChannel= TIM7_IRQn;
	n.NVIC_IRQChannelCmd=ENABLE;
	n.NVIC_IRQChannelPreemptionPriority=1;
	n.NVIC_IRQChannelSubPriority=0;
	NVIC_Init(&n);
	TIM_Cmd(TIM7,ENABLE);
}

void TIM7_IRQHandler()
{
	if(TIM_GetITStatus(TIM7,TIM_IT_Update)!=RESET)
	{	
		OS_TimeMS++;
		T_times++;
		if(T_times>10)
		{
			GUI_TOUCH_Exec();
			T_times=0;
		}
	}
	TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
}

void basic_Init()
{
	delay_init();
	MQ135_init();//��ʼ��mq135
	HC08_init();
	sign_init();
	DS18B20_Init();//��ʼ���¶ȴ�����
	ST7789_Init();//��ʼ����ʾ��
	GUI_Init();//��ʼ��gui
	TP_Init();//��ʼ������
	_tim_init();//tim7
	tim6_init();//~6
}
	


int main()
{
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable,ENABLE);
	RCC->AHBENR|=1<<6;//��crcУ��
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); //�����ж���	
	basic_Init();
	CreateFramewin();
	while(1)
	{
		GUI_Exec();
	}
}
void GUI_X_Unlock(void){}
void GUI_X_Lock(void){}
U32  GUI_X_GetTaskId(void){}
void GUI_X_InitOS(void){}
