#include"delay.h"
void IIC1_Init(void);
uint8_t IIC_ReadOneByte(I2C_TypeDef *I2Cx,uint8_t I2C_driver_ADDR,uint8_t ReadAddr);
void IIC1_WriteOneByte(I2C_TypeDef *I2Cx,uint8_t I2C_driver_ADDR,uint8_t WriteAddr,uint8_t DataToWrite);//iic1д��
void IIC_Read_Array(I2C_TypeDef *I2Cx,uint8_t I2C_driver_ADDR,uint8_t ReadAddr,uint8_t *Data,u16 Num);
