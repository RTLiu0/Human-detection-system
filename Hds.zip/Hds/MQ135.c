#include"MQ135.h"

struct MQ135 mq135={0,0,500}; 
void My_ADC_Adjust(void)
{
	ADC_ResetCalibration(ADC1); //������λУ׼ 
	while(ADC_GetResetCalibrationStatus(ADC1)); //�ȴ���λУ׼����
	ADC_StartCalibration(ADC1); //���� AD У׼
	while(ADC_GetCalibrationStatus(ADC1)); //�ȴ�У׼����
}
void My_ADC_Nvic()
{
	NVIC_InitTypeDef nvic;
	nvic.NVIC_IRQChannel = ADC1_2_IRQn;
	nvic.NVIC_IRQChannelCmd = ENABLE;
	nvic.NVIC_IRQChannelPreemptionPriority = 2;
	nvic.NVIC_IRQChannelSubPriority = 1;
	NVIC_Init(&nvic);

}
void My_ADC_Init(void)
{
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_ADC1|RCC_APB2Periph_AFIO,ENABLE);
	RCC_ADCCLKConfig(RCC_PCLK2_Div6); 
	
	GPIO_InitTypeDef gpio;
	gpio.GPIO_Mode=GPIO_Mode_AIN;
	gpio.GPIO_Pin=GPIO_Pin_1;
	gpio.GPIO_Speed=GPIO_Speed_50MHz;
	GPIO_Init(GPIOA,&gpio);
	
	ADC_DeInit(ADC1);
	ADC_InitTypeDef adc;
	adc.ADC_ContinuousConvMode= ENABLE;
	adc.ADC_DataAlign=ADC_DataAlign_Right;
	adc.ADC_ExternalTrigConv=ADC_ExternalTrigConv_None;
	adc.ADC_Mode=ADC_Mode_Independent;
	adc.ADC_NbrOfChannel=1;
	adc.ADC_ScanConvMode=DISABLE;
	ADC_Init(ADC1,&adc);
	My_ADC_Nvic();
	ADC_RegularChannelConfig(ADC1,ADC_Channel_1,1,ADC_SampleTime_239Cycles5);
	ADC_ITConfig(ADC1,ADC_IT_EOC,ENABLE);
	ADC_Cmd(ADC1,ENABLE);
	My_ADC_Adjust();
	ADC_SoftwareStartConvCmd(ADC1,ENABLE);
}



void ADC1_2_IRQHandler()//ת������ж�
{
	if(ADC_GetITStatus(ADC1,ADC_IT_EOC))
	{
		mq135.vol=(float)ADC_GetConversionValue(ADC1)/4096*3.3;
		//mq135.ppm=pow((3.4880*10*k)/(5-k),(1.0/0.3203));
		mq135.start=1;
	}
	ADC_ClearITPendingBit(ADC1,ADC_IT_EOC);
}
void MQ135_init()//
{
	My_ADC_Init();//PA1
}


